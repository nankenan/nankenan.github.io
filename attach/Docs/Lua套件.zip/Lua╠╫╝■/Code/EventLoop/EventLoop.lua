
--===============================EventLoop===============================

EventLoop = {}
EventLoop.funptrs = {}
EventLoop.event_max_num = 1000

function EventLoop:Init()
    for i = 1, self.event_max_num do
        self.funptrs[i] = {}
    end
end

function EventLoop:AddEvent(id, obj, funptr)
    local tb = self.funptrs[id]
    tb[#tb + 1] = {obj, funptr}
end

function EventLoop:RemoveEvent(id, obj, funptr)
    local tb = self.funptrs[id]
    for i = 1, #tb do
        if tb[i][1] == obj and tb[i][2] == funptr then
            table.remove( tb, i )
            break
        end
    end
end

function EventLoop:RemoveEvents(id)
    self.funptrs[id] = {}
end

function EventLoop:SendEvent(ev)
    local tb = self.funptrs[ev.id]
    for i = 1, #tb do
        if tb[i][1] == nil then
            tb[i][2](ev)
        else
            tb[i][2](tb[i][1], ev)
        end
    end
end