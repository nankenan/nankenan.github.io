

require("EventDef")
require("EventLoop")

--===============================Class===============================
TestClass1 = {}
TestClass1.a = 1;
TestClass1.b = 2;

function TestClass1.OnMemberCallback( self, ev )
	print("member funtion")
end

function OnGlobleCallback(ev)
	print("global funtion")
end

--===============================Main===============================

EventLoop:Init()
EventLoop:AddEvent(1, nil, OnGlobleCallback)
EventLoop:AddEvent(1, TestClass1, TestClass1.OnMemberCallback)
EventLoop:SendEvent(TestEvent1)