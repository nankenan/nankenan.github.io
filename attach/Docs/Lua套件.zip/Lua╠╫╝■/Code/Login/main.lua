
require("protodef")

function Sleep( time )
    local start = os.clock()
    local timespan = 0.0
    while true do
        timespan = os.clock() - start
        if (timespan >= time) then break end
    end
end

function GetEvent_FromQue( )
	local ran = math.random( 1, 2 )
	if ran == 1 then
		return {id = math.random( 1, 2 ), val = math.random( 1, 100)}
	else
		return nil
	end
end

function DispatchEvent( ev )
	if ev.id < 1 or ev.id > #proto then return end
	proto[ev.id](ev)
end

while true do
	local ev = GetEvent_FromQue()
	if ev ~= nil then
		DispatchEvent(ev)
	else
		print("		ev == nil")
	end
	Sleep(1)
end
