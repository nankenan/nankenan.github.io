

function OnReqLogin( ev )
   print("OnReqLogin")
end

function OnReqUserInfo( ev )
    print("OnReqUserInfo")
end

proto = {}
proto[1] = OnReqLogin
proto[2] = OnReqUserInfo
