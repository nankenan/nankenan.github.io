
function class( classname, super )
    local superType = type(super)
    local cls

    if superType ~= "function" and superType ~= "table" then
        superType = nil
        super = nil
    end

    if superType == "function" or (super and super.__ctype == 1) then
        -- inherited from native C++ Object
        cls = {}

        if (superType == "table") then
            -- copy fields from super
            for k,v in pairs(super) do cls[k] = v end
            cls.__create = super.__create
            cls.super = super
        else
            cls.__create = super
            cls.ctor = function() end
        end

        cls.__cname = classname
        cls.__ctype = 1

        function cls.new(...)
            local instance = cls.__create(...)
            -- copy fields from class to native object
            for k,v in pairs do instance[k] = v end
            instance.class = cls
            instance:ctor(...)
            return instance
        end
    else
        -- inherited from Lua Object
        if super then
            cls = {}
            setmetatable(cls, {__index = super})
            cls.super = super
        else
            cls = {ctor = function() end}
        end

        cls.__cname = classname
        cls.__ctype = 2
        cls.__index = cls

        function cls.new(...)
            local instance = setmetatable({}, cls)
            instance.class = cls
            instance:ctor(...)
            return instance
        end
    end

    return cls
end

Creature = class("Creature", nil)
Person = class("Person", Creature)
Knight = class("Knight", Person)
DarkKnight = class("DarkKnight", Knight)

Creature.id = 0
Creature.name = "����"
function Creature:ctor(_id, _name)
    self.id = _id
    self.name = _name
end

DarkKnight.dark_val = 0
function DarkKnight:ctor(_id, _name, _dark_val)
    self.super:ctor(_id, _name)
    self.dark_val = _dark_val
end

a = DarkKnight.new(1, "lqy", 3000)
print(a.id)
print(a.name)
print(a.dark_val)
