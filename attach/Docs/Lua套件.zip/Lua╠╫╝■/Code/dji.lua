
dji = {}

function dji.sleep( time )
    local start = os.clock()
    local timespan = 0.0
    while true do
        timespan = os.clock() - start
        if (timespan >= time) then break end
    end
end

return dji