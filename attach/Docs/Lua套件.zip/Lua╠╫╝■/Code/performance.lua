--lua表性能能测试
--测试数据量1000万

dji = require("dji")

g_max_num = 10000000

--时间函数
function get_run_time(funptr)
    local start = os.clock()
    funptr()
    local time = os.clock() - start
    collectgarbage("collect")
    return time
end

--lua一维数组
function test_single_arr()
    local single_arr = {}
    --增加元素
    for i = 1, g_max_num do
        single_arr[i] = i
    end

    --#访问符性能测试
    assert(#single_arr == g_max_num, "长度错误")

    --删除元素
    for i = 1, g_max_num do
        single_arr[i] = nil
    end
end

--lua锯齿数组
function test_multi_arr()
    local mul_arr = {}
    for i = 1, 1000 do
        mul_arr[i] = {}
        for j = 1, 10000 do
            mul_arr[i][j] = j
        end
    end
end

--lua链表
function test_linked_list()
    local head = nil
    local tail = nil

    --添加节点
    for i = 1, g_max_num do
        if head == nil then
            head = {}
            tail = head
            head.val = i
            head.next = nil
        else
            node = {}
            node.val = i
            node.next = nil
            tail.next = node
            tail = tail.next
        end
    end
end

--lua哈希表-字典-新增元素 O(1)
function test_dictionary_add()
    local dic = {}

    --此处需要减去字符串拼接的时间，才能得出10000000次插入的整体时间
    for i = 1, g_max_num do
        local str = "num" .. i
        dic[str] = true
    end
end

--lua哈希表-字典-访问元素 O(1)
function test_dictionary_find()
    local dic = {}

    for i = 1, g_max_num do
        local str = "num" .. i
        dic[str] = true
    end

    dic.lqy = "李祺缘"
    dic.lhy = "梁辉愉"
    dic.lcl = "龙春霖"
    dic.yq = "杨奇"
    dic.zjf = "张建帆"
    dic.wst = "王诗通"

    local start = os.clock()
    for i = 1, g_max_num do
        dic.lhy = i
    end
    print(string.format( "%s : %f", "lua字典-访问（性能测试）", os.clock() - start) )
end

--主函数
--print("lua一维数组（性能测试） : " .. get_run_time(test_single_arr))
--print("lua锯齿数组（性能测试） ：" .. get_run_time(test_multi_arr))
--print("lua链表（性能测试） : " .. get_run_time(test_linked_list))
--print("lua字典-添加（性能测试） ：" .. get_run_time(test_dictionary_add))
--test_dictionary_find()


dji.sleep(1000)